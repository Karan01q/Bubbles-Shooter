const canvas = document.getElementById('bubble-canvas');
const ctx = canvas.getContext('2d');

// Screen Dimensions
let WIDTH = window.innerWidth;
let HEIGHT = window.innerHeight;

// Constants & Adaptive Layout parameters
let BUBBLE_RADIUS = 22;
let ROW_HEIGHT = 38;
let MAX_COLS = 8;
let SHOOTER_Y = HEIGHT - 60;
let SHOOTER_X = WIDTH / 2;

// Colors Palette
const COLORS = [
  { name: 'red', hex: '#ef4444', glow: 'rgba(239, 68, 68, 0.55)' },
  { name: 'blue', hex: '#3b82f6', glow: 'rgba(59, 130, 246, 0.55)' },
  { name: 'yellow', hex: '#eab308', glow: 'rgba(234, 179, 8, 0.55)' },
  { name: 'green', hex: '#10b981', glow: 'rgba(16, 185, 129, 0.55)' },
  { name: 'purple', hex: '#a855f7', glow: 'rgba(168, 85, 247, 0.55)' }
];

// Utility function to convert Hex to RGB object
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

// Creates a highly visual spherical 3D metallic/glass bubble gradient
function get3DGradient(ctx, x, y, radius, hexColor) {
  const grad = ctx.createRadialGradient(
    x - radius * 0.35,
    y - radius * 0.35,
    radius * 0.05,
    x,
    y,
    radius
  );
  const rgb = hexToRgb(hexColor);
  if (rgb) {
    grad.addColorStop(0, '#ffffff'); // Light source reflection highlight
    grad.addColorStop(0.2, `rgba(${Math.min(255, rgb.r + 70)}, ${Math.min(255, rgb.g + 70)}, ${Math.min(255, rgb.b + 70)}, 1)`);
    grad.addColorStop(0.65, hexColor);
    grad.addColorStop(0.95, `rgba(${Math.max(0, rgb.r - 70)}, ${Math.max(0, rgb.g - 70)}, ${Math.max(0, rgb.b - 70)}, 1)`);
    grad.addColorStop(1, `rgba(${Math.max(0, rgb.r - 110)}, ${Math.max(0, rgb.g - 110)}, ${Math.max(0, rgb.b - 110)}, 1)`); // Bottom edge shadowing
  }
  return grad;
}

// Game State Variables
let bubbles = [];
let bullets = [];
let particles = [];
let floatingTexts = [];
let score = 0;
let highscore = parseInt(localStorage.getItem('bgunner_highscore') || '0');
let gameStarted = false;
let isPaused = false;
let gameOver = false;
let language = 'en'; // 'en' or 'hi'
let soundEnabled = true;
let gameOverReason = '';

let currentAmmo = getRandomColor();
let nextAmmo = getRandomColor();

let lastShotTime = 0;
const SHOOT_COOLDOWN = 110; // Rapid fast auto fire
let isShooting = false;
let pointerX = WIDTH / 2;
let pointerY = HEIGHT / 2;
let descensionTimer = 0;
let DESCENSION_LIMIT = 480; // Decreases as score gets higher

// Audio Synthesizer
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new AudioContext();
  }
}

function playSound(type) {
  if (!soundEnabled) return;
  initAudio();
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);

  const now = audioCtx.currentTime;

  if (type === 'shoot') {
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(750, now + 0.12);
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.linearRampToValueAtTime(0, now + 0.12);
    osc.start(now);
    osc.stop(now + 0.12);
  } else if (type === 'hit') {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.08);
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.linearRampToValueAtTime(0, now + 0.08);
    osc.start(now);
    osc.stop(now + 0.08);
  } else if (type === 'pop') {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(550, now);
    osc.frequency.exponentialRampToValueAtTime(1100, now + 0.08);
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.linearRampToValueAtTime(0, now + 0.08);
    osc.start(now);
    osc.stop(now + 0.08);
  } else if (type === 'gameover') {
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.linearRampToValueAtTime(50, now + 0.5);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.linearRampToValueAtTime(0, now + 0.5);
    osc.start(now);
    osc.stop(now + 0.5);
  }
}

// Language Localization Dictionary
const strings = { 
  en: {
    score: 'SCORE',
    highscore: 'BEST',
    startDesc: 'Shoot bubbles and reduce them to zero. WARNING: Do NOT shoot the BOMBS ( 💣) or it\'s immediate Game Over!',
    startBtn: 'PLAY GAME',
    paused: 'GAME PAUSED',
    pausedDesc: 'Held in stasis. Bubbles are descending slowly!',
    pausedCont: 'CONTINUE',
    goHeader: 'GAME OVER',
    goDesc: 'Your matching sequence finalized.',
    goScore: 'Score',
    goBest: 'Best',
    goAgain: 'PLAY AGAIN'
  },
  hi: {
    score: 'स्कोर',
    highscore: 'सर्वोत्तम',
    startDesc: 'बुलबुलों पर निशाना लगाएं। चेतावनी: बम (💣) को मत छुएं वरना तुरंत गेम ओवर हो जाएगा!',
    startBtn: 'खेल शुरू करें',
    paused: 'खेल रुका हुआ है',
    pausedDesc: 'खेल ठहरा हुआ है। बुलबुले धीरे-धीरे नीचे आ रहे हैं!',
    pausedCont: 'जारी रखें',
    goHeader: 'खेल समाप्त',
    goDesc: 'बुलबुले नीचे पहुँच चुके हैं।',
    goScore: 'कुल अंक',
    goBest: 'सर्वोत्तम',
    goAgain: 'फिर खेलें'
  }
};

function updateUIStrings() {
  const s = strings[language];
  document.getElementById('lbl-stats-score').innerText = s.score;
  document.getElementById('lbl-stats-highscore').innerText = s.highscore;
  document.getElementById('lbl-start-desc').innerText = s.startDesc;
  document.getElementById('lbl-start-btn').innerText = s.startBtn;
  document.getElementById('lbl-paused').innerText = s.paused;
  document.getElementById('lbl-paused-desc').innerText = s.pausedDesc;
  document.getElementById('lbl-paused-continue').innerText = s.pausedCont;
  document.getElementById('go-header').innerText = s.goHeader;
  document.getElementById('go-desc').innerText = gameOverReason || s.goDesc;
  document.getElementById('go-score-lbl').innerText = s.goScore;
  document.getElementById('go-high-lbl').innerText = s.goBest;
  document.getElementById('go-btn-restart').innerText = s.goAgain;
}

function toggleLanguage() {
  language = language === 'en' ? 'hi' : 'en';
  updateUIStrings();
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  const btn = document.getElementById('btn-sound-toggle');
  if (soundEnabled) {
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" /></svg>`;
  } else {
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1zM17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" /></svg>`;
  }
}

function togglePause() {
  if (gameOver || !gameStarted) return;
  isPaused = !isPaused;
  document.getElementById('pause-overlay').classList.toggle('hidden', !isPaused);
}

function getRandomColor() {
  return COLORS[Math.floor(Math.random() * COLORS.length)];
}

// Handle Screen & Canvas Dynamic HD Resizing
function resizeCanvas() {
  WIDTH = window.innerWidth;
  HEIGHT = window.innerHeight;
  
  const dpr = window.devicePixelRatio || 1;
  canvas.width = WIDTH * dpr;
  canvas.height = HEIGHT * dpr;
  
  canvas.style.width = WIDTH + 'px';
  canvas.style.height = HEIGHT + 'px';
  
  ctx.resetTransform();
  ctx.scale(dpr, dpr);
  
  BUBBLE_RADIUS = Math.max(18, Math.min(25, Math.floor(WIDTH / 14)));
  ROW_HEIGHT = Math.floor(BUBBLE_RADIUS * 1.7);
  MAX_COLS = Math.floor(WIDTH / (BUBBLE_RADIUS * 2));
  
  SHOOTER_X = WIDTH / 2;
  SHOOTER_Y = HEIGHT - 60;
}

window.addEventListener('resize', () => {
  resizeCanvas();
});

// Generate Initial Bubble Grid
function generateBubbles() {
  bubbles = [];
  for (let row = 0; row < 5; row++) {
    addRowOfBubbles(row);
  }
}

function addRowOfBubbles(rowNum) {
  const isEven = rowNum % 2 === 0;
  const cols = isEven ? MAX_COLS : MAX_COLS - 1;
  const xOffset = isEven ? BUBBLE_RADIUS : BUBBLE_RADIUS * 2;
  
  // Modified to strictly generate small numbers for the bubbles (e.g., 1 to 5, scaling slightly with high scores up to only 9)
  const baseMin = 1;
  const baseMax = Math.min(9, 5 + Math.floor(score / 1200));

  for (let col = 0; col < cols; col++) {
    const x = xOffset + col * (BUBBLE_RADIUS * 2);
    const y = BUBBLE_RADIUS * 2.5 + rowNum * ROW_HEIGHT;
    
    // 16% Chance to spawn a dangerous Bomb Bubble inside the grid
    const isBomb = Math.random() < 0.16;
    
    if (isBomb) {
      bubbles.push({
        id: Math.random().toString(36).substr(2, 9),
        x,
        y,
        row: rowNum,
        col,
        color: { name: 'bomb', hex: '#111827', glow: 'rgba(239, 68, 68, 0.95)' },
        value: '💣',
        isBomb: true,
        popTimer: 0,
        shake: 0
      });
    } else {
      const color = getRandomColor();
      const value = Math.floor(Math.random() * (baseMax - baseMin + 1)) + baseMin;
      bubbles.push({
        id: Math.random().toString(36).substr(2, 9),
        x,
        y,
        row: rowNum,
        col,
        color,
        value,
        isBomb: false,
        popTimer: 0,
        shake: 0
      });
    }
  }
}

// Start game from custom start overlay
function startGame() {
  initAudio();
  document.getElementById('screen-start').classList.add('opacity-0');
  setTimeout(() => {
    document.getElementById('screen-start').classList.add('hidden');
    gameStarted = true;
    restartGame();
  }, 300);
}

// Setup Inputs
function setupInput() {
  const getPointerPos = (e) => {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: ((clientX - rect.left) / rect.width) * WIDTH,
      y: ((clientY - rect.top) / rect.height) * HEIGHT
    };
  };

  const handleDown = (e) => {
    if (isPaused || gameOver || !gameStarted) return;
    const pos = getPointerPos(e);
    pointerX = pos.x;
    pointerY = pos.y;
    isShooting = true;
    fireBullet();
  };

  const handleMove = (e) => {
    if (!gameStarted) return;
    const pos = getPointerPos(e);
    pointerX = pos.x;
    pointerY = pos.y;
  };

  const handleUp = () => {
    isShooting = false;
  };

  canvas.addEventListener('mousedown', handleDown);
  canvas.addEventListener('mousemove', handleMove);
  window.addEventListener('mouseup', handleUp);

  canvas.addEventListener('touchstart', (e) => { e.preventDefault(); handleDown(e); }, { passive: false });
  canvas.addEventListener('touchmove', (e) => { e.preventDefault(); handleMove(e); }, { passive: false });
  window.addEventListener('touchend', handleUp);
}

// Shoot Logic - parallel dual blaster bullets
function fireBullet() { 
  const now = Date.now();
  if (now - lastShotTime < SHOOT_COOLDOWN) return;
  
  lastShotTime = now;
  const angle = Math.atan2(pointerY - SHOOTER_Y, pointerX - SHOOTER_X);
  const speed = 19;
  
  playSound('shoot');

  const perp = angle + Math.PI / 2;
  const offset = 8;
  const ox = Math.cos(perp) * offset;
  const oy = Math.sin(perp) * offset;

  bullets.push({
    x: SHOOTER_X + ox,
    y: SHOOTER_Y + oy,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    color: currentAmmo
  });
  bullets.push({
    x: SHOOTER_X - ox,
    y: SHOOTER_Y - oy,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    color: currentAmmo
  });

  currentAmmo = nextAmmo;
  nextAmmo = getRandomColor();
}

// Trigger Bomb Detonation immediately Ending Game
function triggerBombExplosion(bombBub) {
  spawnParticles(bombBub.x, bombBub.y, '#f97316');
  spawnParticles(bombBub.x, bombBub.y, '#ef4444');
  spawnParticles(bombBub.x, bombBub.y, '#ffd33d');
  spawnParticles(bombBub.x, bombBub.y, '#000000');
  spawnFloatingText(bombBub.x, bombBub.y, '💥 BOOM!', '#ef4444');
  
  playSound('gameover');
  gameOverReason = language === 'en' 
    ? 'BOOM! You detonated a Bomb! 💣' 
    : 'धमाका! आपने बम पर निशाना लगाया! 💣';
    
  triggerGameOver();
}

// Automatically clear bombs safely if they have no adjacent non-bomb bubbles nearby ("udh jaye")
function checkIsolatedBombs() {
  if (!gameStarted || isPaused || gameOver) return;
  
  for (let i = bubbles.length - 1; i >= 0; i--) {
    const b = bubbles[i];
    if (b.isBomb) {
      let adjacentCount = 0;
      // Scan for non-bomb bubbles close to this bomb
      for (let j = 0; j < bubbles.length; j++) {
        const other = bubbles[j];
        if (other.id !== b.id && !other.isBomb) {
          const dist = Math.hypot(b.x - other.x, b.y - other.y);
          if (dist < BUBBLE_RADIUS * 2.8) {
            adjacentCount++;
          }
        }
      }
      // If isolated (no adjacent helper bubbles), it safely auto-pops away
      if (adjacentCount === 0) {
        playSound('pop');
        spawnParticles(b.x, b.y, '#475569'); // Dark slate safe smoke particles
        const safeMsg = language === 'en' ? 'Safe 💣' : 'सुरक्षित 💣';
        spawnFloatingText(b.x, b.y, safeMsg, '#94a3b8');
        bubbles.splice(i, 1);
      }
    }
  }
}

// Game Over Trigger
function triggerGameOver() {
  gameOver = true;
  playSound('gameover');
  if (score > highscore) {
    highscore = score;
    localStorage.setItem('bgunner_highscore', highscore);
  }
  document.getElementById('score-display').innerText = score;
  document.getElementById('highscore-display').innerText = highscore;
  document.getElementById('go-score-val').innerText = score;
  document.getElementById('go-high-val').innerText = highscore;
  
  updateUIStrings();
  document.getElementById('screen-game-over').classList.remove('hidden');
}

function restartGame() {
  score = 0;
  gameOver = false;
  isPaused = false;
  descensionTimer = 0;
  bullets = [];
  particles = [];
  floatingTexts = [];
  gameOverReason = '';
  
  document.getElementById('score-display').innerText = score;
  document.getElementById('highscore-display').innerText = highscore;
  document.getElementById('screen-game-over').classList.add('hidden');
  document.getElementById('pause-overlay').classList.add('hidden');
  document.getElementById('danger-banner').classList.add('hidden');
  
  generateBubbles();
  updateUIStrings();
}

// Particle Engine
function spawnParticles(x, y, colorHex) {
  for (let i = 0; i < 15; i++) {
    particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 12,
      vy: (Math.random() - 0.5) * 12,
      radius: Math.random() * 5 + 2.5,
      color: colorHex,
      alpha: 1,
      life: 35 + Math.random() * 25
    });
  }
} 

function spawnFloatingText(x, y, text, color) {
  floatingTexts.push({
    x,
    y,
    text,
    color,
    alpha: 1,
    vy: -1.2,
    life: 50
  });
}

// Game loop updates
function update() {
  if (!gameStarted || isPaused || gameOver) return;

  if (isShooting) {
    fireBullet();
  }

  let nearBottom = false;
  const dangerLimitY = HEIGHT - 120;
  
  for (let b of bubbles) {
    if (b.y > dangerLimitY) {
      nearBottom = true;
    }
    if (b.y >= SHOOTER_Y - 25) {
      gameOverReason = language === 'en' ? 'Bubbles crossed the limit!' : 'बुलबुले सीमा पार कर चुके हैं!';
      triggerGameOver();
      return;
    }
  }
  document.getElementById('danger-banner').classList.toggle('hidden', !nearBottom);

  // Update Bullets
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    b.x += b.vx;
    b.y += b.vy;

    // Wall bounces
    if (b.x < BUBBLE_RADIUS || b.x > WIDTH - BUBBLE_RADIUS) {
      b.vx *= -1;
      b.x = b.x < BUBBLE_RADIUS ? BUBBLE_RADIUS : WIDTH - BUBBLE_RADIUS;
      playSound('hit');
    }

    // Screen bounds
    if (b.y < -30 || b.y > HEIGHT + 30) {
      bullets.splice(i, 1);
      continue;
    }

    // Collision with bubbles
    for (let j = bubbles.length - 1; j >= 0; j--) {
      const bub = bubbles[j];
      const dist = Math.hypot(b.x - bub.x, b.y - bub.y);
      
      if (dist < BUBBLE_RADIUS * 1.9) {
        bullets.splice(i, 1);
        handleBubbleHit(bub);
        break;
      }
    }
  }

  DESCENSION_LIMIT = Math.max(280, 500 - Math.floor(score / 350) * 15);

  // Update Bubbles Descent
  descensionTimer++;
  if (descensionTimer >= DESCENSION_LIMIT) {
    descensionTimer = 0;
    bubbles.forEach(b => {
      b.y += ROW_HEIGHT;
    });
    addRowOfBubbles(0);
  }

  // Automatically clear bombs with no adjacent bubbles
  checkIsolatedBombs();

  // Update Particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx;
    p.y += p.vy;
    p.alpha -= 1 / p.life;
    if (p.alpha <= 0) {
      particles.splice(i, 1);
    }
  }

  // Update Floating Texts
  for (let i = floatingTexts.length - 1; i >= 0; i--) {
    const ft = floatingTexts[i];
    ft.y += ft.vy;
    ft.alpha -= 1 / ft.life;
    if (ft.alpha <= 0) {
      floatingTexts.splice(i, 1);
    }
  }
}

// Damage bubble cascade algorithm
function damageBubble(index, amt) {
  if (index < 0 || index >= bubbles.length) return;
  const bub = bubbles[index];
  
  if (bub.isBomb) {
    triggerBombExplosion(bub);
    return;
  }
  
  bub.value -= amt;
  
  if (bub.value <= 0) {
    const x = bub.x;
    const y = bub.y;
    const colorName = bub.color.name;
    
    popBubbleAtIndex(index);
    
    // Search and damage nearby same color bubbles
    for (let i = bubbles.length - 1; i >= 0; i--) {
      const b = bubbles[i];
      if (b.color.name === colorName) {
        const dist = Math.hypot(b.x - x, b.y - y);
        if (dist < BUBBLE_RADIUS * 2.8) {
          const nextIdx = bubbles.findIndex(bubble => bubble.id === b.id);
          if (nextIdx !== -1) {
            damageBubble(nextIdx, 1);
          }
        } 
      } 
    } 
  } else {
    bub.shake = 6;
    spawnFloatingText(bub.x, bub.y - 10, `-1`, '#ff9f43');
  }
}

function handleBubbleHit(bub) {
  playSound('hit');
  if (bub.isBomb) {
    triggerBombExplosion(bub);
    return;
  }
  const index = bubbles.indexOf(bub);
  if (index !== -1) {
    damageBubble(index, 1);
  }
}

function popBubbleAtIndex(index) {
  if (index < 0 || index >= bubbles.length) return;
  const b = bubbles[index];
  playSound('pop');
  spawnParticles(b.x, b.y, b.color.hex);
  
  let scoreReward = 15;
  spawnFloatingText(b.x, b.y, `+${scoreReward}`, b.color.hex);
  
  score += scoreReward;
  document.getElementById('score-display').innerText = score;
  
  bubbles.splice(index, 1);
}

// Render Everything
function draw() {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);

  // Dynamic Premium Radial Background
  let bgGrad = ctx.createRadialGradient(WIDTH / 2, HEIGHT / 2, 20, WIDTH / 2, HEIGHT / 2, Math.max(WIDTH, HEIGHT));
  bgGrad.addColorStop(0, '#191f3c');
  bgGrad.addColorStop(1, '#080a14');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  // Draw Danger zone threshold
  ctx.beginPath();
  ctx.moveTo(0, HEIGHT - 120);
  ctx.lineTo(WIDTH, HEIGHT - 120);
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
  ctx.setLineDash([8, 8]);
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.setLineDash([]);

  // Draw Laser Aim Guide line
  if (isShooting || pointerY < SHOOTER_Y) {
    ctx.beginPath();
    ctx.setLineDash([6, 10]);
    ctx.moveTo(SHOOTER_X, SHOOTER_Y);
    ctx.lineTo(pointerX, pointerY);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Draw Bubbles
  for (let b of bubbles) {
    ctx.save();
    if (b.shake > 0) {
      ctx.translate((Math.random() - 0.5) * b.shake, (Math.random() - 0.5) * b.shake);
      b.shake *= 0.85;
      if (b.shake < 0.2) b.shake = 0;
    }

    if (b.isBomb) {
      // Pulsating Bomb animation
      const pulse = 1 + Math.sin(Date.now() / 120) * 0.08;
      
      ctx.beginPath();
      ctx.arc(b.x, b.y, BUBBLE_RADIUS * pulse, 0, Math.PI * 2);
      ctx.fillStyle = get3DGradient(ctx, b.x, b.y, BUBBLE_RADIUS * pulse, '#111827');
      ctx.shadowBlur = 18 + Math.sin(Date.now() / 120) * 8;
      ctx.shadowColor = 'rgba(239, 68, 68, 0.95)';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(b.x, b.y, BUBBLE_RADIUS * pulse, 0, Math.PI * 2);
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.font = `${Math.floor(16 * pulse)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('💣', b.x, b.y);
    } else {
      ctx.beginPath();
      ctx.arc(b.x, b.y, BUBBLE_RADIUS, 0, Math.PI * 2);
      ctx.fillStyle = get3DGradient(ctx, b.x, b.y, BUBBLE_RADIUS, b.color.hex);
      
      ctx.shadowBlur = 15;
      ctx.shadowColor = b.color.glow;
      ctx.fill();

      ctx.beginPath();
      ctx.arc(b.x, b.y, BUBBLE_RADIUS, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      ctx.font = '900 13px Lexend, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowBlur = 4;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(b.value, b.x, b.y);
    }
    
    ctx.restore();
  }

  // Draw Projectile Bullets
  for (let b of bullets) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(b.x, b.y, BUBBLE_RADIUS * 0.45, 0, Math.PI * 2);
    ctx.fillStyle = get3DGradient(ctx, b.x, b.y, BUBBLE_RADIUS * 0.45, b.color.hex);
    ctx.shadowBlur = 15;
    ctx.shadowColor = b.color.hex;
    ctx.fill();
    ctx.restore();
  }

  // Draw Glowing Cannon Shooter at the bottom
  ctx.beginPath();
  ctx.arc(SHOOTER_X, SHOOTER_Y + 15, 35, Math.PI, 0);
  ctx.fillStyle = '#1e293b';
  ctx.fill();
  ctx.strokeStyle = '#ffd33d';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  const angle = Math.atan2(pointerY - SHOOTER_Y, pointerX - SHOOTER_X);
  ctx.save();
  ctx.translate(SHOOTER_X, SHOOTER_Y);
  ctx.rotate(angle); 
  
  ctx.fillStyle = '#ffd33d';
  ctx.fillRect(0, -9, 36, 18);
  
  ctx.fillStyle = currentAmmo.hex;
  ctx.fillRect(36, -9, 8, 18);
  ctx.restore();

  // Next Ammo Indicator mini circle inside the base
  ctx.beginPath();
  ctx.arc(SHOOTER_X, SHOOTER_Y + 12, 8, 0, Math.PI * 2);
  ctx.fillStyle = nextAmmo.hex;
  ctx.fill();
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Draw Particles
  for (let p of particles) {
    ctx.save();
    ctx.globalAlpha = p.alpha;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
    ctx.fillStyle = p.color;
    ctx.fill();
    ctx.restore();
  }

  // Draw Floating Damage & Score Texts
  for (let ft of floatingTexts) {
    ctx.save();
    ctx.globalAlpha = ft.alpha;
    ctx.font = '900 12px Lexend';
    ctx.fillStyle = ft.color;
    ctx.textAlign = 'center';
    ctx.shadowBlur = 2;
    ctx.shadowColor = 'black';
    ctx.fillText(ft.text, ft.x, ft.y);
    ctx.restore();
  }
}

// Main Loop
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

// Start Initializations
resizeCanvas();
updateUIStrings();
setupInput();
loop();